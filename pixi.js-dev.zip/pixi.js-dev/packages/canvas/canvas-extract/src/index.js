export { default as CanvasExtract } from './CanvasExtract';
