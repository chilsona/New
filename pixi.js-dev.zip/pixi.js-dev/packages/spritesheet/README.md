# @pixi/spritesheet

## Installation

```bash
npm install @pixi/spritesheet
```

## Usage

```js
import { SpritesheetLoader } from '@pixi/spritesheet';
import { Loader } from '@pixi/loaders';
Loader.registerPlugin(SpritesheetLoader);
```