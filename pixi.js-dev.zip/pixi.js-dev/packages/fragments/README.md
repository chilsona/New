# @pixi/fragments

## Installation

```bash
npm install @pixi/fragments
```

## Usage

```js
import '@pixi/fragments';
```