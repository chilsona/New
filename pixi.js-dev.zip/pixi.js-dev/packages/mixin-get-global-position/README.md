# @pixi/mixin-get-global-position

## Installation

```bash
npm install @pixi/mixin-get-global-position
```

## Usage

```js
import '@pixi/mixin-get-global-position';
```