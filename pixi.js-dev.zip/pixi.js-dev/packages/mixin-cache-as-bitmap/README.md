# @pixi/mixin-cache-as-bitmap

## Installation

```bash
npm install @pixi/mixin-cache-as-bitmap
```

## Usage

```js
import '@pixi/mixin-cache-as-bitmap';
```