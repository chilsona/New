# @pixi/utils

## Installation

```bash
npm install @pixi/utils
```

## Usage

```js
import * as utils from '@pixi/utils';
```